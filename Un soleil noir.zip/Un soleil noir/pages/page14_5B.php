<?php session_start(); ob_start(); $_SESSION['mortP']=true; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 14</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Quatre</h1>
      <p class="seul">
        Tu paniques. Tu dois désigner quelqu'un ou Clément sera accusé à tord. <br>
        <?php if (isset($_SESSION['yin'])&&$_SESSION['yin']=='used') {
          echo "<i> «Tu touches le dessin de yin yang sur ta main.<br>";
        } ?>
        <i>«C'est la souris nommé Sasuke, je l'ai vu arriver en retard et elle a un shuriken dans la bouche.»</i> <br>
        Des bruits de foule se font entendre. <i>«Alors c'est lui le tueur ?» -«Allons le chercher ensemble»</i> <br>
        Tous repartent en direction du village déterminés à trouver cette souris. <br>
        <i>«Pfiouu, on l'a échappé belle. T'as vu comment j'ai assuré Clément.»</i> <br>
        Tu te retournes mais sa souris n'est plus là. Seule son sabre de bouche est au sol. Où a-t'il bien pu passer ? <br>
        <i>«Tu cherches celui qui était avec toi n'est-ce pas ?»</i> te demande alors une voix inconnue. <br>
        Tu tournes la tête et tu vois la souris habillée telle la mort. Sa faux en bouche elle s'approche de toi. <br>
        <i>«C'est admirable la rapidité à laquelle tu as pensé aux deux potentiels coupables de ce meurtre. Espérons que tu aies donné la bonne réponse pour sa vie.»</i><br>
        Tu te vois dans l'incapacité de bouger ou de répondre. Tu es complètement paralysée. <i>«Quoi qu'il en soit, c'est l'heure d'un bon retour dans le temps. J'espère que tu es prête.»</i> <br>
        Tu vois la faux s'approcher de toi. Par reflèxe, tu fermes les yeux. <br>
      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : 0px">
          Soudain tu ne sens plus rien. Tu rouvres les yeux et te voilà à nouveau sur le transat du début. Mais cette fois-ci tu es seule. <br>
          Tu parcours le même chemin que la dernière fois mais cette fois-ci personne se semble parler de cette course au fromage. <br>
          Cependant une phrase entendue t'interpelle. <i>«A ce qu'on m'a dit une petite nouvelle a décidé de se lancer dans le survivor dès son premier jour. Elle est complètement inconsciente je crois.»</i><br>
          <i>Le survivor.</i> Ce nom n'augure rien de bon. Et si c'était Prisca. Tu ne peux pas prendre le risque de la laisser seule. <br>
          Tu décides de t'y rendre sans savoir les dangers qui t'attendent. <br>
          Une fois arrivée, tu te rends compte qu'il s'agit d'une succession de plateforme assez dangereuse. Une souris t'interpelle. Elle est habillée différemment et elle porte le nom de Chaman. <br>
          Tu regardes parmi tous les participants et tu vois une souris à la fourrure marron et aux yeux marrons avec comme nom au dessus de sa tête Prisca. <br>
          Cela ne peut être qu'elle. Tu t'apprêtes à essayer d'intéragir avec elle quand le chaman se met à lancer un gigantesque boulet de canon sur 4 personnes les faisant tomber dans le vide. <br>
          Une patte se pose au même moment sur ton épaule. <i>«Elle va y passer si tu ne fais rien et tu le sais.»</i> Tu reconnais cette voix. La mort. <br>
          <i>«Je t'offre une chance de la sauver et de sortir de cette saga. Peux-tu compléter cette phrase : I see who you are ...»</i> <br>
          <a href="page15_6A">You are my ally</a> ou <a href="page15_6B">You are my ennemy.</a>
        </p></div>
      </body>
      </html>
