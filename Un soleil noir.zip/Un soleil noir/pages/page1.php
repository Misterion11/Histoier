<?php session_start(); ob_start()?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 1</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Un</h1>
      <p class="seul">
        <i>"Bon alors, t'es prête à connaître ton tirage ?" </i> <br>
        Cette phrase te sort de tes pensées, tu fronces les sourcils et regardes à droite et à gauche... <br>
        Tu entends une voix derrière toi : <i>"Et donc là j'ai couché avec un troisième gars juste après, mais tu le répètes pas hein ?". </i> <br>
        Aucun doute. Tu es bien en cours de philosophie, et l'autre est encore en train de narrer ses exploits sexuels avec sa légendaire discrétion. <br>
        <i>"<?php echo $_SESSION['Prénom']; ?> ?" </i> Tu te tournes vers la voix. <br>
        <i>"Oh Manon, euh excuse-moi tu disais ?". <br>
          -"Je te demandais si tu voulais que je te tire les cartes". <br>
          -"Euh oui, oui vas-y", </i> réponds-tu, toujours un peu étourdie. <br>
          Manon c'est ta meilleure pote. Elle et toi vous vous êtes trouvées car elle est la seule personne vraiment cool de cette horrible classe. <br>
          Tu regardes vers la fenêtre, le soleil brille et le ciel est dégagé. <br>
          Ton prof déblatère des inepties philosophiques qui ne t'intéresse pas du tout et qui te font plus mal à la tête qu'autre chose. <br>
        </p> </div>
        <div class="paragraphe2">
          <p class="droite" style="margin-top : 75px">
            Tu commences à sortir du brouillard et à te réveiller petit à petit. <br>
            <i>"Dis, Manon" </i> lui demandes-tu alors qu'elle mélange ses cartes. <br>
            <i>-"Oui, que se passe-t-il ?" </i> te répond-elle. <br>
            <i> -"T'as pas l’impression que quelque chose cloche ? Comme si on était pas vraiment là". <br>
              -"T'es vraiment sûre que ça va <?php echo $_SESSION['Prénom']; ?> ? T'as pas dû assez dormir toi encore". </i>  Elle continue à battre les cartes. <br>
              Pourtant tu as passé une bonne nuit, tu as même fait un sublime rêve donc tu ne comprends pas. <br>
              <i>"Bon t'es prête ? C'est parti !" </i> dit-elle en retournant sa première carte.<br>
              Un cri strident se fait alors entendre dans la pièce. C’était Manon.  <br>
              Tu aperçois que la carte représente un soleil mais qui semble devenir progressivement noir. C'est bien la première fois que tu vois cette carte la, tu croyais toutes les connaître à force. <br>
              <i>"Hé, celle-ci je l'ai jamais...". </i> <br>
              Rendez-vous <a href="page2.php"> de l'autre côté du miroir. </a>
            </p> </div>
          </body>
          </html>
