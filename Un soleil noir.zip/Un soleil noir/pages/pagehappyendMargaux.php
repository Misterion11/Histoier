<?php session_start(); ob_start()?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page Happy End Margaux</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Happy End </h1>
      <p class="seul">
        Te voilà en weekend. Enfin ! <br>
        Le réveil est compliqué mais tu as dormi comme un bébé.<br>
        Tu sors de ton lit et te dirige vers ton salon prête à te faire ton bol de Frosties. <br>
        Tu t'assieds dans le canapé avec celui-ci et tu commences à te promener sur les réseaux.<br>
        <i>«Oh c'est aujourd'hui, j'avais oublié.»</i> <br>
        Tu fonces sur Youtube pour suivre en direct le grand reportage dédié au soleil noir.<br>
        <i>«Déjà un an que le phénomène connu sous le nom de soleil noir a frappé sur toute la planète. Nous laissons la parole à Rousselet Sophie, physicienne quantique de renommée.»</i> <br>
        -<i>«Beurk de la physique»</i> penses-tu. <br>
        -<i>«Merci, le soleil noir est donc une anomalie spatio-temporelle qui s'est produite dans le monde entier. Les humains se sont retrouvés en groupe mais on ne sait pas l'élément qui a permis de sortir de tout cela.»</i> <br>

      </i> <br>
    </p> </div>
    <div class="paragraphe2">
      <p class="droite" style="margin-top : 50px">
        Une main vient se poser sur ton épaule. <br>
        <i>«Tu regardes ce truc là ?»</i> te dit la voix. <br>
        -<i>«Ouais mais ça commence à parler de physique»</i> lui réponds-tu. <br>
        -<i>«Bruuuh, coupe ça»</i> te dit-il en se plaçant à côté de toi dans le canapé. <br>
        Cet être humain qui te parle, c'est Clément qui passe pour la première fois quelques jours chez toi. <br>
        <i>«Moi je sais bien ce qu'il s'est passé, tu nous as tous sauvé»</i> t'affirme t-il en te serrant dans ses bras. <i>«T'es la meilleure !»</i> <br>
        -<i>«T'es bête hein.»</i> <br>
        -<i>«Oui m'dame !»</i> te répond il en relâchant son étreinte amoureuse. <i>«C'est pas vraiment nouveau ça je suis un idiot, un idiot qui t'aime fort et pour qui tu comptes énormément.»</i> <br>
        Sans vraiment te laisser le temps de te répondre il enchaîne : <br>
        <i>«Dis ? En étant comme ça à tes côtés, j'ai envie de t'embrasser. Je peux ?»</i> <br>
        Tu peux<a href="pagebisousoui.php"> accepter son baiser.</a> <br>
        Ou bien<a href="pagebisousnon.php"> refuser son baiser.</a>
      </p> </div>
    </body>
    </html>
