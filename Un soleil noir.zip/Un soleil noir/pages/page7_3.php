<?php session_start(); ob_start(); $_SESSION['abandon'] =true;?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 7</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h1>Chapitre Deux</h1>
  <div class="paragraphe">
    <div class="paragraphe1">
      <p class="seul">
        La porte derrière les deux sorcières te semble être la seule échappatoire possible. <br>
        Tu regardes le corps de Clément évanoui, tu vois que les sorcières semblent être attirées par le sang qui coule de sa blessure. <br>
        <i>"C'est le moment"</i> te dis-tu.<br>
        Tu sprintes vers la porte profitant de la distraction que Clément t'a offerte à ses dépends. <br>
        Tu ne te retournes pas quand soudain tu entends un bruit de couteau suivi d'un cri. <br>
        Tu tentes d'ignorer ce son mais tu sais pertinemment ce qu'il vient de se passer. <br>
        Tu ouvres la porte en face de toi et tu te retrouves face au mur avec le symbole infini. <br>
        Cependant celui-ci commence à s'effacer devant tes yeux.<br>
        Le couloir à ta droite que vous aviez emprunté et maintenant barricadé. <br>
        Tu décides donc <a href="page8_1.php">de descendre</a> après que Clément ait été tué par ses sorcières. <br>
      </p>
    </div>
  </body>
  </html>
