<?php session_start(); ob_start(); unset($_SESSION['yin']);?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 7</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h1>Chapitre Deux</h1>
  <div class="paragraphe">
    <div class="paragraphe1">
      <p class="seul">
        Clément est allongé au sol, et tu sais qu'il est impossible que vous puissiez vous en sortir tous les 2, à moins que... <br>
        Tu sors le porte clé, t'approches du corps de Clément, tu le sers contre toi. <br>
        Tu fais de même avec le yin yang et tu fermes les yeux. <br>
        "Chou-fleur, faites que ça serve à quelque chose !" penses-tu. <br>
        Après quelques secondes qui te semble être une éternité, tu ouvres lentement les yeux et tu te rends compte qu'il n'y a plus de sorcière et de couteau. <br>
        Vous vous retrouvez à nouveau devant le symbole infini qui s'efface lentement devant toi. <br>
        Le passage que vous aviez pris à droite est maintenant barricadé. <br>
        Tu poses Clément au sol, passe ta main au niveau de sa blessure qui ne semble plus saigner.  <br>
      </p>
    </div>
    <div class="paragraphe2">
      <p class="droite" style="margin-top : -30px">
        Il finit par se réveiller et se relève doucement. <br>
        <i>'Il s'est passé quoi là au juste ?'</i> te demande-t-il alors qu'il est encore à moitié assommé. <br>
        <i>-'Euuh, je saurais même pas comment te l'expliquer...'</i> lui réponds-tu. <br>
        Tu l'aides à se relever. <br>
        <i>-'Bon... Vu que l'infini s'est effacé tu penses qu'on... peut descendre ?'</i> demande Clément. <br>
        Tu hausses les épaules, c'est possible après tout. <br>
        Vous <a href="page8_2.php">descendez donc les escaliers</a> après être passés à quelques centimètres de la mort.
      </p>
    </div>
  </body>
  </html>
