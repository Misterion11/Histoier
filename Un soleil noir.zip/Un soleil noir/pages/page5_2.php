<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 5</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Deux</h1>
      <p class="seul">
        Bon, tu vas éviter d'assommer le premier humain que tu vois. <br>
         Tu t'approches donc avec méfiance de lui et tu t'exclames. <br>
        <i>"Heyy, vous êtes qui ?"</i> Il n'émet aucun bruit. <br>
        Tu continues à t'approcher et tu le contournes afin de voir son visage et... <br>
        Ohh mais tu connais ce visage. <br>
        <i>"Clément ??" </i>t'exclames-tu, <i> comment c'est possible ! Comment tu peux être dans mon lycée qui ne ressemble même pas à mon lycée ? Et pourquoi le soleil est noir ? Et puis..." </i> <br>
        Tu n'observes aucune réaction de sa part excepté ses yeux qui te suivent. <br>
        Tu lui attrapes la main  : <i>"Hé Clément ?" </i> <br>
        Tu sens que ses doigts commencent à bouger. <br>
        Soudain son bras, puis son corps entier. Il s'écroule. <br>
        <i>"Woooow, je." </i> Il tente de reprendre ses esprits. <br>
        Il prend un grande inspiration  <i>"Alors pour te répondre j'étais dans ma chambre c'est la dernière chose dont je me souvienne. Après quoi j'me suis réveillé ici, debout et dans l'incapacité de bouger mon corps, puis tu es arrivée et tu m'as libéré." </i>
        Il se relève avec ton aide. <br>
        <i> "Euuh par contre le soleil est noir ? J'suis pas sûr d'avoir suivi <?php echo $_SESSION['Prénom']; ?>". </i>
        </p>
      </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : 150px">
          Vous vous rendez à une fenêtre au bout du couloir. <br>
          <i>"Oh okayy" </i> s'exclame-t-il. <i>"Donc je me suis téléporté dans ton lycée, tu es la première personne que je vois, et le soleil est noir. Tout va bien". </i> <br>
          Tu le regardes avec désinvolture, non ça ne va pas. Vous êtes tous les deux aussi perdus l'un que l'autre, mais en même temps tu es contente de le voir même si tu aurais préféré que ça se passe dans d'autres circonstances. <br>
          Clément te regarde à son tour en frottant sa tête, et te prend dans ses bras. <br>
          <i>"Je sais pas trop ce qu'il se passe mais j'suis vraiment heureux que ça soit avec toi que ça se passe." </i> <br>
          Tu rougis... Vous décidez tous les deux de descendre à l'étage inférieur qui n'est pas bloqué de ce côté de l'étage. <br>
          Cependant avant de descendre tu lui demandes d'où vient ce crayon qu'il avait dans la main. <br>
          Il bredouille : <i>"C'est euuh, une surprise."</i> Il te prend la main. <br>
          Et vous <a href="page6.php">descendez à l'étage inférieur.</a><br>
        </p>
      </div>
    </body>
    </html>
