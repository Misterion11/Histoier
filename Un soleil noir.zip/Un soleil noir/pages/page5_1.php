<?php
session_start();
ob_start();
$_SESSION['assommé'] =true;
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 5</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Deux</h1>
      <p class="seul">
        Tu ne peux pas prendre le risque, il est potentiellement armé. <br>
        Tu te faufiles donc tel un chat derrière lui, tu arrives à son contact et tu lui assènes un violent coup derrière la tête. <br>
        Il s'effondre au sol et tu aperçois son visage qui te semble familier... <br>
        Tu t'en approches et...  <i>"MERDE Clément !" </i> hurles-tu.<br>
        En effet tu ne l'avais pas reconnu sûrement car tu ne l'avais jamais vu en vrai, mais il s'agit bien de ce jeune homme que tu connais depuis quelques mois avec lequel tu as beaucoup échangé par messages. <br>
        Tu retires délicatement sa capuche et tu regardes sa blessure. Elle saigne légèrement mais il semblerait qu'il ait la tête dure. <br>
        Il est toujours dans les vapes. Par réflexe tu regardes dans ses mains et tu n'observes qu'un simple crayon. <br>
        Comment as-tu pu croire que c'était une arme. <br>
        Après une dizaine de minutes il finit par se réveiller. <br>
        <i>"Aiiie" </i> dit-il en se frottant la tête. <i>"Ça fait mal !" </i> <br> Tu le regardes avec insistance. <br>
        <i>"Désolée ! Mais comment c'est possible ! Comment tu peux être dans mon lycée qui ne ressemble même pas à mon lycée ? Et pourquoi le soleil est noir ? Et puis..." </i> <br>

      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : -30px">
          Tu t'interromps pour le laisser parler. <br>
          <i>-"Déjà, en premier lieu AIIIIE, ça va pas la tête de m'assommer. Ensuite pour toutes les autres questions je sais pas... J'étais dans ma chambre c'est la dernière chose dont je me souvienne.
            Après je me suis réveillé ici, debout et dans l'incapacité de bouger mon corps. Il semblerait que tu m'en aies libéré." </i> <br>
            <i>-"Oopsii" </i> lances-tu. <br>
            <i>-"Mais d'ailleurs comment ça le soleil est noir ?". </i> <br>
            Tu l'aides à se relever, et vous vous rendez à une fenêtre au bout du couloir. <br>
            <i>"Oh okayy" </i> s'exclame-t-il. <i>"Donc je me suis téléporté dans ton lycée, t'es la première personne que je vois, et le soleil est noir. Tout va bien". </i> <br>
            Tu le regardes avec désinvolture, non ça ne va pas. Vous êtes tous les deux aussi perdus l'un que l'autre, mais en même temps tu es contente de le voir même si tu aurais préféré que ça se passe dans d'autres circonstances. <br>
            Clément te regarde à son tour en frottant sa tête, et te prend dans ses bras. <br>
            <i>"Je sais pas trop ce qu'il se passe mais j'suis vraiment heureux que ça soit avec toi que ça se passe". </i> <br>
            Tu rougis... Vous décidez tous les deux de descendre à l'étage inférieure qui n'est pas bloqué de ce côté de l'étage. <br>
            Cependant avant de descendre tu lui demandes d'où vient ce crayon qu'il avait dans la main. <br>
            Il bredouille : <i>"C'est euuh, une surprise."</i> Il te prend la main. <br>
            Et vous <a href="page6.php">descendez à l'étage inférieur.</a><br>
          </p>
        </div>
      </body>
      </html>
