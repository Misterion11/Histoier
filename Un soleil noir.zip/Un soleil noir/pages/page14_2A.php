<?php session_start(); ob_start(); $_SESSION['mortCl'] =true;?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 14</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Qautre</h1>
      <p class="seul">
        Tu en es sûre, la bonne heure c'est 20h02 ! <br>
        Tu t'empresses de cliquer sur la bonne réponse. <br>
        La roue s'arrête soudainement. Laissant Clément suspendu, tête à l'envers. <br>
        Tu te retournes afin de comprendre ce qu'il se passe quand tu vois la mort te faucher.
        Tu regardes tout autour de toi, le magasin est rempli à ras bord. Tu prends un paquet de chocolatine sur une étagère et tu regardes la date limite de consommation : "20 mars 2035". <br>
        Attends une seconde. Tu l'as déjà vécu ça. <br>
        Ce paquet. Cette date. Que s'est-il passé au juste ? <br>
        Tu entends une voix provenant de devant toi. <br>
        C'est celle de Prisca . <br>
        <i>«C'est pas l'heure de manger des pains aux chocolats hein [prénom]. Allez viens !»</i> <br>
        <i>«On dit chocolatine !»</i> penses-tu. <br>
        Tu rattrapes Prisca quand une voix raisonne alors dans ta tête <i>«Un de moins».</i> <br>
        San vous interrompt soudain. <br>
        <i>«Mesdemoiselles, c'est par ici je vous prie.»</i> <br>
      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : px">
          Elle vous montre un grande porte située aux rayons jouets. <br>
          Tu passes devant et tu l'ouvres, Prisca te suivant à quelques pas derrière. <br>
          Lors des premiers mètres, vous ne voyez strictement rien si ce n'est la lumière provenant de là où vous veniez. <br>
          Soudain la porte se claque ce qui fait sursauter Prisca. Dans la foulée, vous entendez la sirène d'un train ce qui fait à nouveau sursauter Prisca. <br>
          <i>«C'est pas possible»</i> hurle-t-elle. <br>
          -<i>«Silence ! Ça tourne ! Que la lumière soit !»</i> <br>
          Et la lumière fut à cet instant précis. <br>
          Vous voilà débarquées en plein tournage d'un film dans un train et pas n'importe lequel. L'orient Express. <br>
          Est-ce la chose la plus folle de cette journée ? Pas vraiment. <br>
          Vous vous retrouvez dans un wagon en face de la mort. Une nouvelle fois. <br>
           Celle-ci vous raconte qu'un meurtre a eu lieu. La victime était nommée Merlin et que les deux hommes présents ici était sur les lieux du crime. <br>
          Il finit par indiquer c'que ce n'est pas un crime passionnel. Il vous demande ensuite d'établir lequel des deux est le meurtrier : <br>
          <a href="page15_3.php">Choisir l'homme</a> au chapeau nommé Escanor <br>
          <a href="page15_4.php">Choisir l'homme</a> au costard nommé Ban. <br>
        </p></div>
      </body>
      </html>
