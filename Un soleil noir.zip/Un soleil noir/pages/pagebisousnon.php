<?php session_start(); ob_start();?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Page Happy End Margaux</title>
    <link rel="stylesheet" href="../style.css">
  </head>
  <body>
    <h1>Happy End ❤</h1>
    <div class="paragraphe">
      <div class="paragraphe1">
        <p class="seul">
          Tu hoches la tête de gauche à droite.<br>
          Clément te regarde en souriant. <br>
          <i>«D'accord alors si c'est comme ça ! Bataille de coussins !»</i> <br>
          Vous vous levez tous les deux, saisissez vos armes respectives et commencez le duel. <br>
          Le résultat de ce combat appartient au monde réel. Quoiqu'il en soit, ce moment sera magique. <br>  
    <h1>Fin</h1>
        </p>
      </div>
  </body>
</html>
