<?php session_start(); ob_start(); $_SESSION['mortP'] =true; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 14</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Quatre</h1>
      <p class="seul">
        <?php if (isset($_SESSION['yin'])&&$_SESSION['yin']=='used') {
          echo "Tu sors ton yin yang que tu avais encore sur toi, tu le sers et soudain.... <br>";
        } ?>
        La réponse te semble évidente, Ban n'aurait aucune raison de faire du mal à Merlin alors qu'Escanor aurait des motifs. Tu le désignes donc. <br>
        Le détective l'arrête tandis que Ban fond en larme dans les bras de Prisca. <br>
        «<i>J'ai eu si peur, si vous saviez j'ai eu si peur !»</i> <br>
        À cet instant, la sirène retentit à nouveau. Puis les lumières du train s'éteignent. <br>
        Puis, un flash aveuglant t'illumines ! <br>
        Lorsque tu parviens à rouvrir les yeux, la mort est en face de toi et te fauche la seconde d'après. <br>
        Tu prends un paquet de chocolatine sur une étagère et tu regardes la date limite de consommation : <i>20 mars 2035</i>. <br>
        Attends une seconde. Tu l'as déjà vécu ça. <br>
        Ce paquet. Cette date. Que s'est-il passé au juste ? <br>
        Tu relèves la tête, tu ne vois plus ni San ni Prisca. <i>«Est-ce que j'ai rêvé ?»</i>
        Cependant tu continues d'entendre cette musique. Tu la connais et étrangement, c'est une musique que tu as découverte avec Clément. <br>
        Ce n'est pas un hasard, tu en es sûre ! <br>
        Tu n'as vraiment le temps de réaliser ce qu'il vient de se passer que tu suis la musique à travers les immenses rayons du supermarché. <br>
        Tu entends le son de plus en plus fort. Tu te rapproches ça y est ! <br>
      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : px">

          Tu tournes à gauche, puis à droite, puis 2 rayons à gauche, puis tout droit puis... <br>
          Tu arrives à l'origine de cette musique. Une épaisse brume y est présente. <br>
          Tu t'avances en faisant attention quand tu arrives  soudain en face d'une grande roue à laquelle est attaché un homme nu. <br>
          La brume est épaisse, distinguer son visage est complexe. Soudain une grande voix roque s'élève derrière toi. <br>
          <i>«Ainsi tu es arrivée ici <?php echo $_SESSION['Prénom']; ?>.»</i> <br>
          La brume se dissipe soudainement. Tu te retournes pour voir à qui appartient cette voix; <br>
          Il s'agit d'une personne habillée avec une cape noire recouvrant tout son corps avec une faux en main. Oui, cette personne est habillée comme la mort.<br>
          La roue derrière toi se met à tourner. Tu l'aurais presque oubliée. La brume s'étant dissipée tu peux enfin savoir à qui appartient ce visage. <br>
          Stupeur ! C'est celui de Clément. <br>
          La mort arrive derrière toi et pose sa main sur ton épaule. <br>
          <i>«Tu n'as pas pu le sauver la première fois, réessayons si tu le veux bien.»</i><br>
          Un tableau numérique sort du sol en face de toi. <br>
          Il s'allume et écrit la chose suivante : <br>
          <i>Quelle est l'heure de naissance de Clément ?</i> <br>
          <a href="page15_1.php">Réponse A : 21h02</a> <br>
          <a href="page15_2.php">Réponse B : 20h02</a> <br>
        </p></div>
      </body>
      </html>
