<?php session_start(); ob_start(); $_SESSION['mortP']=true;?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 14</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Quatre</h1>
      <p class="seul">
      Tu réfléchis quelques secondes. Tu as une chance sur deux. <i>«Je choisis... Eugène.» <br>
      «Très bien jeune fille, voyons en direct si tu as raison» </i> te dit-elle en te souriant. <br>
      La pression s'installe. La mort s'exclame : <i>«J'arrive pas à me décider décidement»</i> <br>
      Il marche devant vous tous, vous frôlant tour à tour avec sa faux. <br>
      Soudain il s'arrête et vous dit à tous en rigolant. <br>
      <i>«J'ai une idée.»</i> Il pointe alors la faux vers la personne la plus proche de lui. <i>«Am,Stram,Gram,Pic»</i> commence-t-il lentement décalant à chaque mot sa faux d'une personne. <br>
      <i>«Pic et pic et colégram Bour et bour et ratatam, Am, stram, gram. »</i> <br>
      La faux s'arrête sur ton visage. Et si la vieille folle avait menti. Et si c'était toi qui allait mourir. <br>
      Il reprend alors. <i>«Mais comme la reine et le roi ne le veulent pas ça sera toi !»</i>
      Sa faux s'arrête alors sur Glenn. Tu avais tord. <br>
      Il l'abat alors sur le crane du jeune homme. Dans la panique tu fermes et les yeux et c'est alors qu'un silence de mort règne dans la forêt. <br>
      Tu rouvres lentement tes yeux mais il n'y a plus personne dans les alentours. Prisca aussi a disparu. Et la vieille femme aussi. <br>
      L'a-t'elle sauvée ? Rien n'est moins sûr.

      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : px">
          Tu regardes autour de toi et tu te rends compte que tu es revenue à ton point de départ. Cependant tes mains sont toujours liées. <br>
          <i>«Je peux pas refaire le même chemin, si je retombe sur les sauvages je serai dans la même merde»</i> penses-tu. <br>
          Tu décides donc de partir de l'autre côté, espérant trouver quelque chose pour libérer tes mains et peut-être de l'aide pour comprendre où tu es. <br>
          Tu fais une bonne dizaine minutes de marche avant de tomber sur une station service. Tu t'y rends espérant trouver de l'aide. <br>
          <i>«Hello, y a quelqu'un ici ?»</i> demandes-tu timidement en rentrant. Un serpent géant surgit alors de derrière le contoir. <br>
          <i>«Bonssssssssssssssoir, puis-je vous ssssssservir ?»</i> Un serpent qui parle. Bon. Cela n'arrive même plus à te surprendre. <br>
          <i>«Euh oui, j'aimerais savoir où je suis et savoir si vous avez de quoi me libérer les mains.»</i> <br>
          <i>«Ccccccccccela peut ssssssssssse faire sssssi vous répondez à mon égnime.»</i>. <br>
          Tu l'écoutes, après tout une égnime c'est rien par rapport à un pari sur une mort. <br>
          <i>«Mon premier désigne le mot oui dans une autre langue. Mon second désigne la possession. Mon tout est le prénom de son frère. Qui suis-je ?»</i>
          Deux idées te viennent alors en tête : Si-mon et Da-mien. Mais laquelle choisir ? <br>
          <a href="Page15_3A">Choisir Simon</a> ou <a href="Page15_3B">Choisir Damien</a> <br>
        </p></div>
      </body>
      </html>
