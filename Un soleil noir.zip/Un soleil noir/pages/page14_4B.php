<?php session_start(); ob_start(); $_SESSION['mortP']=true; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 14</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Quatre</h1>
      <p class="seul">
        Tu réfléchis quelques secondes. Tu as une chance sur deux. <br>
        Tu presses la gâchette de droite. Une énorme détonation se fait entendre. <br>
        Le recul te fait basculer en arrière. Impossible pour toi de voir si la flèchette est partie et par conséquent si tu as appuyé sur la bonne gâchette. <br>
        Une fois arrivée sur le sol un silence religieux retentit alors. Tu poses l'arme à terre et tu te relèves. <br>
        Tu es seule à l'intérieur de cet immense cratère. Le titan, Prisca et Clément ont disparu. <br>
        <i>«Héhoo ? Y a quelqu'un ?»</i> clames-tu avec la voix la plus forte possible. <br>
        <i>«Oui moi je suis là.»</i> Tu te retournes et stupeur. Te voici en face à face avec la personne habillée comme la mort. Elle tend sa faux vers toi et te dit alors d'une voix enjouée :
        <i>«Prête à mourir et à revivre ? »</i> <br>
        Avant même que tu ne réalises ce qu'il vient de te dire, il te fauche. <br>
        Tu ne sens alors plus rien. Tu rouvres les yeux et te revoilà devant le lycée. Le corps du tigre est au sol avec deux tranquilisants en lui. <br>
        Tu te rends compte qu'il y a Clément présent à tes côtés. <br>
        Celui-ci te tire par la manche. <i>«<?php echo $_SESSION['Prénom']; ?> reste pas là, y a un tireur.»</i> <br>
        Tu le suis sans trop comprendre ce qu'il vient de se passer.
      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : px">
          Après avoir couru et vous être mis à l'abri tu t'assieds sur le sol. <br>
          <i>«Dis Clément, tu crois que Prisca a survécu ? Vous aviez tous disparu et la mort m'a fauché et me revoilà ici.»<br>
            -«Pour être honnête, je ne comprends pas vraiment ce que tu dis. Prisca ? Elle était là ?»</i> te demande-t'il avec confusion. <br>
            Tu n'as pas le temps de lui répondre qu'un aboiement de chien se fait entendre. Est-ce la chienne de John ? <br>
            Tu te relèves et c'est alors qu'un chien à trois têtes surgit devant vous. <br>
            Paniqués, vous commencez à courir.  <i>«Pas encore !»</i> hurlez-vous en choeur. <br>
            Vous empruntez une petite ruelle à droite. Mais il s'agit d'un cul de sac. <br>
            Vous vous retournez vous attendant à vous faire attaquer par le cerbère mais rien. <br>
            Tu remarques alors qu'un mouton est dessiné sur le mur à ta droite. <br>
            <i>«Il faut toujours regarder derrière soi.»</i> vient te souffler une voix dans l'oreille. <br>
            Tu fais volt-face et tu te retrouves face à la mort. Derrière elle, tu vois Clément. Emmuré. <br>
            La mort fait glisser sa faux sur le corps du jeune homme à travers la dalle de béton qui laisse apparaître les courbes de son corps. <br>
            Je te laisse une chance de sauver le petit prince derrière moi. Dis moi ma chère. De quelle manière meurt-il à la fin ? <br>
            <a href="page15_5A.php">La morsure d'araignée</a> ou bien<a href="page15_5B.php"> la morsure de serpent.</a>
          </p></div>
        </body>
        </html>
