<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 8</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Trois</h1>
      <p class="seul">
        Vous descendez tous les deux les marches de cet énième escalier espérant cette fois-ci ne pas tomber sur une énième horreur. <br>
        Mais tu positives ! Vous avez réussi tous les deux à vous sortir de cette merde, même si vous êtes passés à deux doigts de la mort. <br>
        Vous arrivez à l'étage suivant et encore une fois l'escalier pour continuer est obstrué. <br>
        Vous vous regardez avec un regard qui en dit long sur votre agacement respectif et sans un mot vous empruntez le couloir à votre droite. <br>
        <i>"Encore le même couloir long avec des portes, et sûrement des sorcières à l'intérieur pffff" </i> t'exclames-tu à haute voix. <br>
        Clément lâche un léger rire nerveux. <br>
        Vous avancez, pas à pas quand soudain le sol commence à se dérober sous vos pieds. <br>
        <i>"C'est quoi ça encore !" </i> hurlez-vous en toute synchro. <br>
        Par réflexe, Clément saisit ta main et vous commencez à courir, espérant pouvoir échapper au sol qui disparaît petit à petit. <br>
        Sauf que... Le sol en face de vous commence aussi à disparaitre. <br>
        En clair, il n'y a aucune échappatoire. <br>
      </p>
    </div>
    <div class="paragraphe2">
      <p class="droite" style="margin-top : 50px">
        Vous ne sentez plus rien sous vos pieds, et vous commencez à tomber dans un vide qui vous semble être infini. <br>
        Vous vous relevez sans blessure, mais quelque chose cloche, les portes de ce nouveau couloir dans lequel tu te situes commencent au plafond. <br>
        C'est comme si le couloir était retourné, ou comme si vous marchiez vous même au plafond. <br>
        Vous décidez de continuer à avancer ne comprenant rien à ce qu'il se passe quand vous entendez un bruit derrière vous ressemblant à... <br>
        Un... Rugissement... Un rugissement de tigre ?! <br>
        Tu te retournes et tu te retrouves face à face avec un tigre vert. <br>
        Tu jettes un coup d'œil vers Clément qui s'évapore en quelques dixièmes de seconde. <br>
        Tu prends peur et tu commences à courir dans la direction opposée au tigre. <br>
        Cependant celui-ci te rattrape aisément, te plaque au sol quand soudain tu entends : <br>
        <i>"Bon alors, t'es prête à connaître ton tirage ?" </i> <br>
        <a href="page9.php">Se relever</a> pour voir à qui appartient cette voix.
      </p>
    </div>
  </body>
  </html>
