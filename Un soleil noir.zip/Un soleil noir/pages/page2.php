<?php session_start(); ob_start();  unset($_SESSION['yin']); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 2</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Un</h1>
      <p class="seul">
        Le son se coupe, tu n'entends plus rien. Pas même le son de ta voix. <br>
        Quelques secondes plus tard c'est ta vue, puis ton touché qui disparaissent. <br>
        Puis soudain... <br>
        Tu rouvres les yeux, affalée sur ta table. <br>
        Tu te relèves péniblement, et tu observes à nouveau autour de toi. <br>
        Tu es toujours dans cette foutu salle de classe mais elle est vide. <br>
        Il n'y a plus aucune lumière seul l'obscurité est maître en ces lieux. Cependant, il reste tout de même un faible faisceau de lumière dehors. <br>
        Tu t'approches de la fenêtre, tu ouvres le store fermé et... <br>
        Tu n'en reviens pas. Le soleil est noir, mais pas comme une éclipse non, c'est bien le soleil. Notre soleil mais noir et celui-ci émet une lumière noire comme... Sur la carte de Manon... <br>
        Tu finis d'ouvrir le store laissant entrer cette lumière obscure et tu scrutes ta classe. <br>
        Elle est vide enfin, quasiment. <br>
        Tu remarques qu'à la place derrière toi se tient une personne. Tu t'approches et... Horreur ! <br>
      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : 75px">
          Ce n’est pas une personne mais bien un squelette ! celui d'Inès tu supposes. <br>
          Tu sors ton portable dans l'espoir de pouvoir obtenir de l'aide, ou au moins d'avoir une lampe torche mais impossible de l'allumer. <br>
        <i>"C'est pas possible, c'est bien le moment que ma malédiction de la technologiqe frappe...". </i> <br>
          Tu attrapes ton sac de cours dans l'espoir d'y trouver quelque chose d'utile, seulement celui-ci est vide. <br>
        <i>"Bon et bah j'vais pas m'éterniser là". </i> Tu décides de sortir de la classe. <br>
          Passée la porte, tu remarques que le couloir est différent de celui de ton lycée. <br>
          Il y a un escalier sur ta gauche et un long couloir sur ta droite. En face de toi tu peux voir un tag d'un yin yang avec une flèche en dessous montrant la droite. Par ailleurs, tu entends une musique provenant d'une des salles au fond du couloir. <br>
          Tu parviens à entendre les mots suivants : <i>Only fools rush in.</i> <br>
          Un choix s'offre donc à toi : <br>
          Descendre les escaliers pour <a href="page4.php">passer à l'étage suivant.</a> <br>
          Ou bien <a href="page3.php">parcourir le couloir</a> à la recherche de la musique.
        </p>
      </div>
      </body>
      </html>
