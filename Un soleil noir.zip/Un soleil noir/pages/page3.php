<?php session_start(); ob_start();
$_SESSION['yin'] =true; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 3</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="paragraphe">
    <div class="paragraphe1">
      <h1>Chapitre Un</h1>
      <p class="seul">
        Tu décides donc de parcourir le sombre couloir cherchant l'origine de cette musique. <br>
        Tu avances prudemment en essayant d'ouvrir chacune des portes. <br>
        Cependant le résultat est toujours le même : verrouillée, verrouillée et encore verrouillée. <br>
        Le problème étant que tu n'as pas l'impression de te rapprocher véritablement de la musique. <br>
        Elle te semble venir de partout et de nulle part à la fois. <br>
        Tu continues désespérément d'essayer chacune des poignées en vain... <br>
        Après avoir parcouru les trois quarts du couloir, tu aperçois de la lumière sous l'une des portes. <br>
        Tu t'approches donc de celle-ci, et tu descends lentement la poignée et... Miracle ! La porte est ouverte. <br>
        Tu franchis donc le pas puis arrives dans une salle extrêmement lumineuse qui t'aveugles totalement. <br>
        Tu avances. Lentement. Pas à pas. Tu te rends compte que de part et d'autre de la salle d'immenses projecteurs t'éclairent. <br>
        Tu te retournes et... tu te retrouves attachée sur une chaise de dentiste avec une lampe qui illumine l’ensemble de ta personne. <br>
      </p> </div>
      <div class="paragraphe2">
        <p class="droite" style="margin-top : 75px">
          Tu ne comprends pas ce qu'il t'arrive, tu tentes de te débattre mais les liens sont extrêmement serrés.  <br>
          Tu essaies de crier mais aucun son ne sort de ta bouche. Rien, pas même un gémissement... <br>
          Tu fermes les yeux, et tu tentes de reprendre tes esprits... <br>
          C’est alors que tu entends à nouveau la chanson mais cette fois-ci par dessus, tu entends une voix. Une voix assez grave. <br>
          Dans un premier temps, tu ne parviens pas à distinguer les mots qui sont prononcés. <br>
          Mais cette voix te semble apaisante. <br>
          Finalement, tu distingues une phrase : <br>
          <i>"Viens me chercher, même capuché je t'attendrai".</i> <br>
          Tu rouvres les yeux et te voilà de retour dans cette salle. <br>
          Les projecteurs ont disparu et seule la lumière du soleil noir est présente. <br>
          Seule une table est présente en face de toi sur laquelle se trouve un porte clé avec un yin  yang dessus. Une aura mystérieuse émane de celui-ci. <br>
          Tu décides de le prendre et tu sors de cette étrange salle. <br>
          N'ayant plus rien à faire dans ce couloir, tu prends les escaliers bien décidée à comprendre ce qui est en train de t'arriver. <br>
          <a href="page4.php">Prendre les escaliers</a> pour passer à l'étage suivant.
        </p> </div>
      </body>
      </html>
<?php ob_end_flush(); ?>
