<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page 0</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h1>Histoire</h1>
  <div class="paragraphe">
    <div class="paragraphe1">
      <p class="seul">
        Coucouuu, cette page est une page exclusive pour toi. <br>
        Alors voilà, on s'approche à grands pas des 6 mois de notre rencontre. <br>
        Déjà 6 mois que ma vie s'est vue chamboulée par ton arrivée. <br>
        Et j'ose espérer que ce sont 6 mois qui ouvrent le bal à une vie entière à tes côtés. <br>
        Sur ces quelques mots, je te laisse lire cette modeste histoire, j'espère qu'elle te plaira. <br>
        Bisouuuuuuuuus, je t'aime fort ! Et ne t'en fais pas, je ferai la vaisselle :)<br>
        <a href="page0.php"><img title="Clique moi dessus" src="../Images/coeur.jpg" alt="" height="200px"> </a>
      </p>
    </div>
  </body>
  </html>
