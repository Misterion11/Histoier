<?php session_start(); ob_start();?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Page 0</title>
    <link rel="stylesheet" href="../style.css">
  </head>
  <body>
    <h1>Histoire</h1>
    <div class="paragraphe">
      <div class="paragraphe1">
        <p class="seul">
          L'aventure ne peut pas s'arrêter là, tu dois retenter là où tu as échoué. <br>
          Mais où et quand aller ? <br>
          <a href="page4.php">Assommer ou non ?</a> <br>
          <a href="page6.php">Que faire face aux sorcières ?</a> <br>
          <a href="page10.php">Porte principale ou autre sortie ?</a><br>
        </p>
      </div>
  </body>
</html>
