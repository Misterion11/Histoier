<?php session_start(); ob_start();?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Page Happy End Margaux</title>
    <link rel="stylesheet" href="../style.css">
  </head>
  <body>
    <h1>Happy End ❤❤</h1>
    <div class="paragraphe">
      <div class="paragraphe1">
        <p class="seul">
          Tu hoches la tête de haut en bas. <br>
          C'est alors qu'il passe sa main dans ton cou dégageant gentiment tes cheveux.<br>
          Sur sa main tu peux d'ailleurs observer sa partie du tatouage que vous avez en commun : un yin yang. <br>
          Il approche lentement sa tête de la tienne et vient alors déposer ses lèvres contre les tiennes. <br>
          Il t'embrasse avec délicatesse sans te quitter du regard. Après de magnifiques secondes vos lèvres se quittent. <br>
          <i>«Tu sais, y a comme un goût de reviens y»</i> te dit-il très affectueusement. <br>
          Tu le regardes en souriant. <br>
          <i>«Mais d'abord. Bataille de coussins !»</i> crie-t-il. <br>
          Vous vous levez tous les deux, saisissez vos armes respectives et commencez le duel. <br>
          Le résultat de ce combat appartient au monde réel. Quoiqu'il en soit, ce moment sera magique. <br>
    <h1>Fin</h1>
        </p>
      </div>
  </body>
</html>
